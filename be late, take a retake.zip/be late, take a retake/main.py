import pygame
import sys
import random
import time

pygame.init()
W, H = 1250, 750
screen = pygame.display.set_mode((W, H), pygame.RESIZABLE)
pygame.display.set_caption("Be late, take a RETAKE")
pygame.display.set_icon(pygame.image.load("image/kbtu.png"))
bg_color = (0, 0, 0)

class VictoryScreen:
    def __init__(self, image_path):
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (W, H))

    def show(self, screen):
        screen.blit(self.image, (0, 0))
        pygame.display.update()
        time.sleep(10)  # Display the image for 10 seconds

def main_game(level):
    abylaikhan_img = pygame.image.load('image/abylaikhan.jpg')
    bg_x = 0
    bg_y_a = (H - abylaikhan_img.get_height()) // 2

    clock = pygame.time.Clock()
    FPS = 60

    class Enemy(pygame.sprite.Sprite):
        def __init__(self, y, speed):
            super().__init__()
            self.image = pygame.image.load("enemies/left_first.png")
            self.image = pygame.transform.scale(self.image, (100, 100))
            self.rect = self.image.get_rect()
            self.rect.x = W
            self.rect.y = y
            self.enemy_speed = speed

        def move(self):
            self.rect.x -= self.enemy_speed
            return True if self.rect.x + self.rect.width > 0 else False

    class Player(pygame.sprite.Sprite):
        def __init__(self, x, y, speed, timer):
            super().__init__()
            original_image = pygame.image.load("player/r_r_still.png")
            self.image = pygame.transform.scale(original_image, (100, 100))
            self.rect = self.image.get_rect()
            self.rect.center = (x, y - 5)
            self.can_move_up = True
            self.can_move_down = True
            self.currentLine = 3
            self.player_speed = speed
            self.timer = timer
            self.collision_occurred = False

        def move(self):
            keys = pygame.key.get_pressed()
            new_player_x = self.rect.x
            new_player_y = self.rect.y

            if keys[pygame.K_LEFT]:
                new_player_x -= self.player_speed
            if keys[pygame.K_RIGHT] and self.rect.x < W - self.rect.width:
                new_player_x += self.player_speed

            if keys[pygame.K_UP] and self.can_move_up and self.rect.y > 0:
                if self.currentLine > 1:
                    new_player_y -= 50
                    self.currentLine -= 1
                    self.can_move_up = False
            elif not keys[pygame.K_UP]:
                self.can_move_up = True

            if keys[pygame.K_DOWN] and self.can_move_down and self.rect.y < H - self.rect.height - 50:
                if self.currentLine < 3:
                    new_player_y += 50
                    self.currentLine += 1
                    self.can_move_down = False
            elif not keys[pygame.K_DOWN]:
                self.can_move_down = True

            player_width, player_height = 80, 80
            self.rect.width = player_width
            self.rect.height = player_height

            self.rect.x = max(0, min(W - self.rect.width, new_player_x))
            self.rect.y = max(50, min(H - self.rect.height - 50, new_player_y))

            # Decrease the timer by 1 for each frame
            self.timer -= 1

            # Check for victory condition
            if level == 1 and self.rect.x >= W - self.rect.width:
                show_screen("image/am_cool.jpeg")
                return False  # Exit the game loop

            # Check for defeat condition
            if self.timer <= 0:
                print(f'Level {level} - Game Over! Time ran out.')
                show_screen("image/a_uncool.jpeg" if level == 2 else "image/av_uncool.jpeg")
                return False  # Exit the game loop

            self.collision_occurred = False
            return True

        def enemyHittedPlayer(self):
            if not self.collision_occurred:
                self.timer -= 60  # Subtract 1 minute on collision
                self.collision_occurred = True
                print(f'Level {level} - Minutes left till the lesson: {self.timer / 60} minutes')

                # Kill the collided enemies
                collided_enemies = pygame.sprite.spritecollide(self, enemies, True)
                for enemy in collided_enemies:
                    all_sprites.remove(enemy)
                    enemies.remove(enemy)

    enemies = pygame.sprite.Group()
    all_sprites = pygame.sprite.Group()

    P1 = Player(160, 470, 5 - level, 600)  # Adjusted player speed for each level
    all_sprites.add(P1)

    running = True
    spawn_timer = 0
    font = pygame.font.SysFont(None, 36)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        for entity in all_sprites:
            if not entity.move():
                running = False  # Exit the game loop

        if level != 3:  # Spawn enemies only for the first two levels
            spawn_timer += 1
            if spawn_timer % (FPS * (4 - level)) == 0:
                num_enemies = random.randint(1, 5)
                for _ in range(num_enemies):
                    enemy_speed = random.uniform(3 + level, 6 + level)  # Increase speed with level
                    new_enemy = Enemy(P1.rect.y, enemy_speed)
                    enemies.add(new_enemy)
                    all_sprites.add(new_enemy)

        if pygame.sprite.spritecollideany(P1, enemies):
            P1.enemyHittedPlayer()

        screen.fill(bg_color)

        abylaikhan_img = pygame.transform.scale(abylaikhan_img, (W, abylaikhan_img.get_height()))
        screen.blit(abylaikhan_img, (bg_x, bg_y_a))

        all_sprites.draw(screen)

        # Display the timer on the screen
        timer_text = font.render(f'Time left: {P1.timer // 60} minutes', True, (255, 255, 255))
        screen.blit(timer_text, (10, 10))

        # Display the goal on the screen
        goal_text = font.render(f'Goal: Reach the room {300 + level * 10}', True, (255, 255, 255))
        screen.blit(goal_text, (10, 40))

        pygame.display.update()

        clock.tick(FPS)

def show_screen(image_path):
    victory_screen = VictoryScreen(image_path)
    victory_screen.show(screen)

def start_screen():
    kbtu_img = pygame.image.load('image/kbtu.png')
    original_size = kbtu_img.get_size()

    bg_x = 0
    new_size = (original_size[0] * 2.5, original_size[1] * 2.5)
    kbtu_img = pygame.transform.scale(kbtu_img, new_size)

    clock = pygame.time.Clock()
    FPS = 60

    button_rect = pygame.Rect(W // 2 - 100, H // 2 + 100, 200, 50)
    button_color = (150, 75, 0)
    button_text = pygame.font.SysFont(None, 50).render("START", True, (0, 0, 0))

    while True:
        screen.fill(bg_color)

        screen.blit(kbtu_img, ((W - new_size[0]) // 2, (H - new_size[1]) // 2))

        pygame.draw.rect(screen, button_color, button_rect)
        screen.blit(button_text, (W // 2 - 58, H // 2 + 111))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_rect.collidepoint(event.pos):
                        print("START button clicked!")
                        for level in range(1, 4):
                            main_game(level)

        pygame.display.update()

        clock.tick(FPS)

if __name__ == "__main__":
    start_screen()
